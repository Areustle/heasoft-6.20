# LaTeX2HTML 2002-2-1 (1.70)
# Associate internals original text with physical files.


$key = q/sec:physics/;
$ref_files{$key} = "$dir".q|node110.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_George1999/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:14a/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:5b/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Hollenbach1978/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_topbase/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Karzas1966/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xstar2xspec/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:xstarflow/;
$ref_files{$key} = "$dir".q|node144.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:4b/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bautista1999/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Field1971/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Shull1979/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:6_/;
$ref_files{$key} = "$dir".q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:16a/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:xstar2xspec/;
$ref_files{$key} = "$dir".q|node146.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Harrington1989/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xstarinput/;
$ref_files{$key} = "$dir".q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Lotz1967/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lexington/;
$ref_files{$key} = "$dir".q|node149.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bautista1997/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kallman1980/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Tucker1971/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Gould1970/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:internals/;
$ref_files{$key} = "$dir".q|node131.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bautista2000/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:3_oxygen_1__other_metals_0__etable/;
$ref_files{$key} = "$dir".q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Mendosa1982/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Osterbrock1974/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ross1979/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_chianti/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:spectra/;
$ref_files{$key} = "$dir".q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_opacityp/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_London1979/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:introduction/;
$ref_files{$key} = "$dir".q|node2.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pitfalls/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:9b/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:15b/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Krolik1981/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:7a/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:4a/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:3a/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:9a/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Press/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:14b/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Butler1980/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:8a/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Nahar1999/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sampsonzhang/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Comparison_of_grid19b__19c__and_warmabs/;
$ref_files{$key} = "$dir".q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Aldrovandi1973/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:2/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Verner1995/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:3b/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ross1978/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Dalgarno1981/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Grevesse1996/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Hatchett1976/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Illarionov1979/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:5a/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Arnaud1985/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kallman1982/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:8b/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:12/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Weisheit1974/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Barfield1972/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:overview/;
$ref_files{$key} = "$dir".q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kwan1981/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:6a/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:1a/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:13b/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:1b/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:atomicdatabase/;
$ref_files{$key} = "$dir".q|node163.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:troubleshooting/;
$ref_files{$key} = "$dir".q|node159.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:warmabs/;
$ref_files{$key} = "$dir".q|node99.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:7b/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:walkthrough/;
$ref_files{$key} = "$dir".q|node7.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Davidson1979/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:15a/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kaastra1989/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:revision/;
$ref_files{$key} = "$dir".q|node188.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bautista1998/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kallman1983/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Nahar2000/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:11a/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:16b/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:6b/;
$ref_files{$key} = "$dir".q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Arnaud1992/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:installation/;
$ref_files{$key} = "$dir".q|node166.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Bambynek1972/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:11b/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:1_cosmic_abundances__mtable/;
$ref_files{$key} = "$dir".q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Hummer1968/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Raymond1976/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:_7_/;
$ref_files{$key} = "$dir".q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Halpern1980/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ironp/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:4_oxygen_1__other_metals_0__mtable/;
$ref_files{$key} = "$dir".q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Tarter1969/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Hummer1971/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:13a/;
$ref_files{$key} = "$dir".q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Dalgarno1978/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:2_cosmic_abundances__etable/;
$ref_files{$key} = "$dir".q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:output/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_McCray1977/;
$ref_files{$key} = "$dir".q|node217.html|; 
$noresave{$key} = "$nosave";

1;

