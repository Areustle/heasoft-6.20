# LaTeX2HTML 2002-2-1 (1.70)
# Associate images original text with physical files.


$key = q/C_1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img273.png"
 ALT="$C_1$">|; 

$key = q/varepsilon_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img73.png"
 ALT="$\varepsilon_i$">|; 

$key = q/y_{max};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img78.png"
 ALT="$y_{max}$">|; 

$key = q/kappa_max(varepsilon);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="68" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="$\kappa_max(\varepsilon)$">|; 

$key = q/Cgeq;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img137.png"
 ALT="$C\geq$">|; 

$key = q/{displaymath}b={{sqrt{{{rm{log}(tau_{line})}}over{1+tau_{line}slashtau_w}}eqno{(8)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="337" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img185.png"
 ALT="\begin{displaymath}b={{\sqrt{{\rm log}(\tau_{line})}}\over{1+\tau_{line}/\tau_w}} \eqno{(8)} \end{displaymath}">|; 

$key = q/M_i^j;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img87.png"
 ALT="$M_i^j$">|; 

$key = q/{displaymath}rate=10^{-12}*(r1slashT+r2+T*(r3+T*r4))*T^{3slash2}*e^{-r5slashT}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="467" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img276.png"
 ALT="\begin{displaymath}rate=10^{-12}*(r1/T+r2+T*(r3+T*r4))*T^{3/2}*e^{-r5/T}\end{displaymath}">|; 

$key = q/C;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img135.png"
 ALT="$C$">|; 

$key = q/leqCleq;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img136.png"
 ALT="$\leq C \leq$">|; 

$key = q/sim;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img140.png"
 ALT="$\sim$">|; 

$key = q/(Heating)=(Cooling).;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="186" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img165.png"
 ALT="$(Heating) = (Cooling).$">|; 

$key = q/{displaymath}sigma=r1*(varepsilonslashr5)^{r2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img269.png"
 ALT="\begin{displaymath}\sigma=r1*(\varepsilon/r5)^{r2}\end{displaymath}">|; 

$key = q/C_m^{obs}=C_m^{mod};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img113.png"
 ALT="$C_m^{obs}=C_m^{mod}$">|; 

$key = q/A_{nm};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img107.png"
 ALT="$A_{nm}$">|; 

$key = q/J_varepsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img169.png"
 ALT="$J_\varepsilon$">|; 

$key = q/L;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img143.png"
 ALT="$L$">|; 

$key = q/P_{esc.,line}^{(in)}=(1-C)P_{esc.,line}(tau_{i}^{(in)});MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="254" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img217.png"
 ALT="$P_{esc., line}^{(in)}=(1-C) P_{esc., line}(\tau_{i}^{(in)})$">|; 

$key = q/{displaymath}kappa=ffrac{L_varepsilon^{source}slash10^{38}}{L_varepsilon^{xstar}slashL_{tot}^{xstar}}frac{1}{D_{kpc}^2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="183" HEIGHT="60" BORDER="0"
 SRC="|."$dir".q|img120.png"
 ALT="\begin{displaymath}\kappa=f \frac{L_\varepsilon^{source}/10^{38}}{L_\varepsilon^{xstar}/L_{tot}^{xstar}} \frac{1}{D_{kpc}^2}\end{displaymath}">|; 

$key = q/{displaymath}frac{dL_i^{(1)}}{dR}=-kappa_{cont}(varepsilon)L_i^{(1)}+4piR^2j_i(R)P_{esc,line}^{(in)}eqno{(16)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="437" HEIGHT="52" BORDER="0"
 SRC="|."$dir".q|img212.png"
 ALT="\begin{displaymath}\frac{d L_i^{(1)}}{dR}=-\kappa_{cont}(\varepsilon) L_i^{(1)}
+ 4 \pi R^2 j_i(R) P_{esc,line}^{(in)} \eqno{(16)} \end{displaymath}">|; 

$key = q/{displaymath}DeltaR=min({{rm{emult}slashkappa_max(varepsilon),Rslash{{rm{nsteps}){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="287" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="\begin{displaymath}\Delta R = min( {\rm emult}/\kappa_max(\varepsilon), R/{\rm nsteps})\end{displaymath}">|; 

$key = q/L_{varepsilon}^{(1')};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="47" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img241.png"
 ALT="$L_{\varepsilon}^{(1')}$">|; 

$key = q/L_{tot}^{source}=L_{tot}^{xstar};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="125" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img122.png"
 ALT="$L_{tot}^{source}=L_{tot}^{xstar}$">|; 

$key = q/geq;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="$\geq$">|; 

$key = q/M_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img88.png"
 ALT="$M_i$">|; 

$key = q/{displaymath}n_eGamma_e={{sigma_T}over{m_ec^2}}left(int{varepsilonJ_varepsilondv}-4kTint{J_varepsilondvarepsilon}right)eqno{(1)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="423" HEIGHT="54" BORDER="0"
 SRC="|."$dir".q|img166.png"
 ALT="\begin{displaymath}n_e\Gamma_e={{\sigma_T}\over{m_ec^2}}\left(\int{\varepsilon
...
...psilon}
-4kT\int{J_\varepsilon d\varepsilon}\right) \eqno{(1)} \end{displaymath}">|; 

$key = q/_Z;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img262.png"
 ALT="$_Z$">|; 

$key = q/Deltavarepsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img228.png"
 ALT="$\Delta\varepsilon$">|; 

$key = q/xi=Lslash(nR^2);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="102" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="$\xi = L/(nR^2)$">|; 

$key = q/^{22};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img132.png"
 ALT="$^{22}$">|; 

$key = q/P_{esc.,line}(tau_{line});MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="111" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img216.png"
 ALT="$P_{esc., line}(\tau_{line})$">|; 

$key = q/x_{ij};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="26" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img84.png"
 ALT="$x_{ij}$">|; 

$key = q/{figure}{epsfxsize{=5.6in<comment_mark>20{epsfysize{=7.0in<comment_mark>21{epsffile{warmabsfig5.epsi}{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="643" HEIGHT="804" BORDER="0"
 SRC="|."$dir".q|img98.png"
 ALT="\begin{figure}
\epsfxsize =5.6in % narrow the plot\epsfysize =7.0in % shorten the plot
\epsffile{warmabsfig5.epsi}\end{figure}">|; 

$key = q/{displaymath}M_i=exp(-(E_i^0+Sigma_jx_jE_i^j)){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="212" HEIGHT="45" BORDER="0"
 SRC="|."$dir".q|img89.png"
 ALT="\begin{displaymath}
M_i=exp(-(E_i^0+\Sigma_j x_j E_i^j))
\end{displaymath}">|; 

$key = q/^4;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$^4$">|; 

$key = q/j_varepsilon(R);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img196.png"
 ALT="$j_\varepsilon(R)$">|; 

$key = q/^7;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$^7$">|; 

$key = q/L_{varepsilon}^{(6)}+L_{varepsilon}^{(7)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img248.png"
 ALT="$L_{\varepsilon}^{(6)}+L_{\varepsilon}^{(7)}$">|; 

$key = q/n_{i};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img66.png"
 ALT="$n_{i}$">|; 

$key = q/xi)>;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img92.png"
 ALT="$\xi)&gt;$">|; 

$key = q/{displaymath}M_i(x)=Sigma_jM_i(x_j)omega_j{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="158" HEIGHT="45" BORDER="0"
 SRC="|."$dir".q|img75.png"
 ALT="\begin{displaymath}M_i(x)=\Sigma_j M_i(x_j)\omega_j\end{displaymath}">|; 

$key = q/{LMODDIR}:;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="111" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img131.png"
 ALT="${LMODDIR}:$">|; 

$key = q/10^{12};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="$10^{12}$">|; 

$key = q/^{38};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="$^{38}$">|; 

$key = q/n=Pslash(kT);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="95" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$n=P/(kT)$">|; 

$key = q/F_varepsilon^{obs};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="37" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img111.png"
 ALT="$F_\varepsilon^{obs}$">|; 

$key = q/{figure}{epsfxsize{=5.6in<comment_mark>64{epsfysize{=7.0in<comment_mark>65{epsffile{xstar2xspec.eps}{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="640" HEIGHT="798" BORDER="0"
 SRC="|."$dir".q|img254.png"
 ALT="\begin{figure}
\epsfxsize =5.6in % narrow the plot\epsfysize =7.0in % shorten the plot
\epsffile{xstar2xspec.eps}\end{figure}">|; 

$key = q/D;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img119.png"
 ALT="$D$">|; 

$key = q/le10^{24};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img161.png"
 ALT="$\le10^{24}$">|; 

$key = q/10^{34};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$10^{34}$">|; 

$key = q/10^x;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img251.png"
 ALT="$10^x$">|; 

$key = q/xigeq2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img289.png"
 ALT="$\xi \geq 2$">|; 

$key = q/P_{esc,cont.}^{(in)}(R)=(1-C)slash2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="193" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img209.png"
 ALT="$P_{esc, cont.}^{(in)}(R)=(1-C)/2$">|; 

$key = q/varepsilon_{line};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="37" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img261.png"
 ALT="$\varepsilon_{line}$">|; 

$key = q/H^0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img259.png"
 ALT="$H^0$">|; 

$key = q/{displaymath}kappa=frac{{{rm{EM}}{4piD^2}times10^{-10}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="139" HEIGHT="52" BORDER="0"
 SRC="|."$dir".q|img134.png"
 ALT="\begin{displaymath}
\kappa=\frac{{\rm EM}}{4\pi D^2} \times 10^{-10}
\end{displaymath}">|; 

$key = q/^{+3};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img288.png"
 ALT="$^{+3}$">|; 

$key = q/n_z;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img171.png"
 ALT="$n_z$">|; 

$key = q/_{ij};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img286.png"
 ALT="$_{ij}$">|; 

$key = q/tau_{cont}^{(in)}(varepsilon);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img245.png"
 ALT="$\tau_{cont}^{(in)}(\varepsilon)$">|; 

$key = q/{displaymath}rate=2.2e-6*sqrt(chir)*fchi*expo(-1.slashchir)slash(e*sqrt(e)){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="490" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img279.png"
 ALT="\begin{displaymath}rate = 2.2e-6*sqrt(chir)*fchi*expo(-1./chir)/(e*sqrt(e))\end{displaymath}">|; 

$key = q/>;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img95.png"
 ALT="$&gt;$">|; 

$key = q/x_j;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img74.png"
 ALT="$x_j$">|; 

$key = q/F_n^{mod};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img102.png"
 ALT="$F_n^{mod}$">|; 

$key = q/L_i^{(1)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img214.png"
 ALT="$L_i^{(1)}$">|; 

$key = q/F_varepsilon^{obs}=fL_varepsilon^{source}slash(4piD^2);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img117.png"
 ALT="$F_\varepsilon^{obs}=f L_\varepsilon^{source}/(4\pi D^2)$">|; 

$key = q/^{18};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img57.png"
 ALT="$^{18}$">|; 

$key = q/{displaymath}kappa=frac{C_m^{obs}}{C_m^{mod}}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img114.png"
 ALT="\begin{displaymath}\kappa = \frac{C_m^{obs}}{C_m^{mod}}\end{displaymath}">|; 

$key = q/beta;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img324.png"
 ALT="$\beta$">|; 

$key = q/gamma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img62.png"
 ALT="$\gamma$">|; 

$key = q/tau_{line};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img186.png"
 ALT="$\tau_{line}$">|; 

$key = q/(1leqileq{{rm{N}_{{rm{I});MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="98" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img67.png"
 ALT="$(1 \leq i \leq {\rm N}_{\rm I})$">|; 

$key = q/tau_{cont.}(R,varepsilon);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="85" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img194.png"
 ALT="$\tau_{cont.}(R,\varepsilon)$">|; 

$key = q/varepsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img227.png"
 ALT="$\varepsilon$">|; 

$key = q/xi;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$\xi $">|; 

$key = q/kappa_{cont}(varepsilon);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="62" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img201.png"
 ALT="$\kappa_{cont}(\varepsilon)$">|; 

$key = q/{displaymath}F_n^{mod}=frac{L_varepsilon^{xstar}}{L_{tot}^{xstar}}frac{10^{38}}{)^2}left(frac{Deltavarepsilon}{varepsilon}right){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="241" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img104.png"
 ALT="\begin{displaymath}F_n^{mod}=\frac{L_\varepsilon^{xstar}}{L_{tot}^{xstar}} \frac...
...\rm kpc})^2} \left(\frac{\Delta\varepsilon}{\varepsilon}\right)\end{displaymath}">|; 

$key = q/{displaymath}kappa=ffrac{L_{tot}^{source}slash10^{38}}{D_{kpc}^2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="137" HEIGHT="60" BORDER="0"
 SRC="|."$dir".q|img125.png"
 ALT="\begin{displaymath}\kappa=f \frac{L_{tot}^{source}/10^{38}}{ D_{kpc}^2}\end{displaymath}">|; 

$key = q/DeltaR_{max}=Nslashn;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="117" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="$\Delta R_{max}=N/n$">|; 

$key = q/2-C;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img138.png"
 ALT="$2-C$">|; 

$key = q/^8;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img291.png"
 ALT="$^8$">|; 

$key = q/{displaymath}L_{line,varepsilon}^{(out)}=Sigma_{inimidvarepsilon_i-varepsilonmidrepsilon-varepsilon_i)}{Deltavarepsilon}eqno(21){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="406" HEIGHT="52" BORDER="0"
 SRC="|."$dir".q|img225.png"
 ALT="\begin{displaymath}L_{line, \varepsilon}^{(out)}=\Sigma_{i \ni \mid\varepsilon_i...
...\phi(\varepsilon-\varepsilon_i) }{\Delta \varepsilon} \eqno(21)\end{displaymath}">|; 

$key = q/{displaymath}M_i(y)=(M_i(y_{max})-M_i(0)){{y}over{y_{max}}}+M_i(0){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="324" HEIGHT="55" BORDER="0"
 SRC="|."$dir".q|img79.png"
 ALT="\begin{displaymath}M_i(y)=(M_i(y_{max})-M_i(0)){{y}\over{y_{max}}}+M_i(0)\end{displaymath}">|; 

$key = q/L_{varepsilon}^{(5)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img247.png"
 ALT="$L_{\varepsilon}^{(5)}$">|; 

$key = q/L_varepsilon^{(6)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img236.png"
 ALT="$L_\varepsilon^{(6)}$">|; 

$key = q/tau_{cont}^{(tot)}(varepsilon);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img205.png"
 ALT="$\tau_{cont}^{(tot)}(\varepsilon)$">|; 

$key = q/n;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="$n$">|; 

$key = q/(ratein)=(rateout);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="171" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img164.png"
 ALT="$(rate in) = (rate out)$">|; 

$key = q/{displaymath}L_varepsilon^{(2)}=L_{varepsilon}^{(inc)}e^{-tau_{cont}^{(tot)}(varepsilon)}eqno{(13)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="357" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img204.png"
 ALT="\begin{displaymath}L_\varepsilon^{(2)}=L_{\varepsilon}^{(inc)} e^{-\tau_{cont}^{(tot)}(\varepsilon)} \eqno{(13)} \end{displaymath}">|; 

$key = q/^6;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img290.png"
 ALT="$^6$">|; 

$key = q/10^{21};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="$10^{21}$">|; 

$key = q/Gamma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img130.png"
 ALT="$\Gamma$">|; 

$key = q/kappa_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img223.png"
 ALT="$\kappa_i$">|; 

$key = q/tau_{cont}^{(out)}(varepsilon);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img211.png"
 ALT="$\tau_{cont}^{(out)}(\varepsilon)$">|; 

$key = q/kappa(varepsilon);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img192.png"
 ALT="$\kappa(\varepsilon)$">|; 

$key = q/{displaymath}A(varepsilon)=varepsilon^{alpha}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="\begin{displaymath}
A(\varepsilon) = \varepsilon^{\alpha}
\end{displaymath}">|; 

$key = q/10^{-8};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="$10^{-8}$">|; 

$key = q/C_2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img274.png"
 ALT="$C_2$">|; 

$key = q/L_varepsilon^{(5)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img235.png"
 ALT="$L_\varepsilon^{(5)}$">|; 

$key = q/{displaymath}L_varepsilon^{(3)}=int_{R_{inner}}^{R_{outer}}{4piR^2j_varepsilon(Rvarepsilon)}P_{esc,cont.}^{(in)}(R)}dReqno{(15)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="462" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img207.png"
 ALT="\begin{displaymath}L_\varepsilon^{(3)}=\int_{R_{inner}}^{R_{outer}}{4\pi R^2 j_\...
...}^{(in)}(\varepsilon)}
P_{esc, cont.}^{(in)}(R)}dR \eqno{(15)} \end{displaymath}">|; 

$key = q/{displaymath}frac{{{rm{d}L_{varepsilon}^{(1')}}{{{rm{d}R}=-kappa_{cont}(varepsilpsilon-varepsilon_i)}{Deltavarepsilon}eqno{(27)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="580" HEIGHT="80" BORDER="0"
 SRC="|."$dir".q|img240.png"
 ALT="\begin{displaymath}\frac{{\rm d}L_{\varepsilon}^{(1')}}{{\rm d}R}=-\kappa_{cont}...
...i(\varepsilon-\varepsilon_i) }{\Delta \varepsilon} \eqno{(27)} \end{displaymath}">|; 

$key = q/(varepsilon_{max}-varepsilon_{min})slash(4{{rm{ln}(varepsilon_{max}slashvarepsilon_{min}));MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="246" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img60.png"
 ALT="$(\varepsilon_{max}-\varepsilon_{min})
/(4 {\rm ln}(\varepsilon_{max}/\varepsilon_{min}))$">|; 

$key = q/^{-1};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$^{-1}$">|; 

$key = q/F_H;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img152.png"
 ALT="$F_H$">|; 

$key = q/He^0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img267.png"
 ALT="$He^0$">|; 

$key = q/P_{esc,cont.}^{(out)}(R)=(1+C)slash2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="193" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img210.png"
 ALT="$P_{esc, cont.}^{(out)}(R)=(1+C)/2$">|; 

$key = q/M;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img80.png"
 ALT="$M$">|; 

$key = q/leq;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="$\leq$">|; 

$key = q/{figure}{epsfxsize{=5.6in<comment_mark>18{epsfysize{=7.0in<comment_mark>19{epsffile{warmabsfig4.epsi}{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="642" HEIGHT="803" BORDER="0"
 SRC="|."$dir".q|img97.png"
 ALT="\begin{figure}
\epsfxsize =5.6in % narrow the plot\epsfysize =7.0in % shorten the plot
\epsffile{warmabsfig4.epsi}\end{figure}">|; 

$key = q/>>;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img325.png"
 ALT="$\&gt;\&gt;$">|; 

$key = q/omega_j;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img76.png"
 ALT="$\omega_j$">|; 

$key = q/{displaymath}P_{esc.,line}(tau_{line})={{1-e^{-2tau_{line}}}over{2tau_{line}}}(tau_{line}leq1)eqno{(7)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="424" HEIGHT="54" BORDER="0"
 SRC="|."$dir".q|img184.png"
 ALT="\begin{displaymath}P_{esc., line}(\tau_{line})={{1-e^{-2 \tau_{line}}}\over{2 \tau_{line}}} (\tau_{line}\leq 1) \eqno{(7)} \end{displaymath}">|; 

$key = q/Lambda;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img249.png"
 ALT="$\Lambda$">|; 

$key = q/varepsilon_0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img191.png"
 ALT="$\varepsilon_0$">|; 

$key = q/nuF_nu;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="$\nu F_\nu$">|; 

$key = q/L_{varepsilon}^{(1)}=L_{varepsilon}^{(inc)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="99" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img200.png"
 ALT="$L_{\varepsilon}^{(1)}=L_{\varepsilon}^{(inc)}$">|; 

$key = q/C_m^{obs};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="37" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img110.png"
 ALT="$C_m^{obs}$">|; 

$key = q/{displaymath}rate=r1*10^{-6}*e^{-r2slashT}*(1+r3*e^{-r4slashT})slashT^{3slash2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="373" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img265.png"
 ALT="\begin{displaymath}rate=r1*10^{-6}*e^{-r2/T}*(1+r3*e^{-r4/T})/T^{3/2}\end{displaymath}">|; 

$key = q/{displaymath}j_varepsilon={{1}over{4pi}}n_zn_e{{32Z^2e^4h}over{3m^2c^3}}left({{p)^{1slash2}e^{-hnuslashkT}g_{ff}(T,Z,r)eqno{(9)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="476" HEIGHT="54" BORDER="0"
 SRC="|."$dir".q|img188.png"
 ALT="\begin{displaymath}j_\varepsilon={{1}\over{4\pi}}n_zn_e{{32Z^2e^4h}\over{3m^2c^3...
...0}\over{3kT}}\right)^{1/2}e^{-h\nu/kT}g_{ff}(T,Z,r) \eqno{(9)} \end{displaymath}">|; 

$key = q/Ln;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img158.png"
 ALT="$Ln$">|; 

$key = q/L_{varepsilon}^{(inc)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img203.png"
 ALT="$L_{\varepsilon}^{(inc)}$">|; 

$key = q/epsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img162.png"
 ALT="$\epsilon$">|; 

$key = q/10^{38};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$10^{38}$">|; 

$key = q/^{Auger}_{ij};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img283.png"
 ALT="$^{Auger}_{ij}$">|; 

$key = q/^{-3};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="$^{-3}$">|; 

$key = q/^{-10};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="$^{-10}$">|; 

$key = q/{displaymath}kappa=ffrac{L_{tot}^{xstar}slash10^{38}}{D_{kpc}^2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="131" HEIGHT="60" BORDER="0"
 SRC="|."$dir".q|img123.png"
 ALT="\begin{displaymath}\kappa=f \frac{L_{tot}^{xstar}/10^{38}}{D_{kpc}^2}\end{displaymath}">|; 

$key = q/{displaymath}kappa_{line}(varepsilon)=Sigma_{inimidvarepsilon_i-varepsilonmidleqilon}kappa_iphi(varepsilon-varepsilon_i)eqno(22){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="401" HEIGHT="46" BORDER="0"
 SRC="|."$dir".q|img226.png"
 ALT="\begin{displaymath}\kappa_{line}(\varepsilon)=\Sigma_{i \ni \mid\varepsilon_i -\...
...\varepsilon}
\kappa_i \phi(\varepsilon-\varepsilon_i) \eqno(22)\end{displaymath}">|; 

$key = q/^{radiative}_{ij};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img282.png"
 ALT="$^{radiative}_{ij}$">|; 

$key = q/%;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img59.png"
 ALT="$\%$">|; 

$key = q/n_e;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img168.png"
 ALT="$n_e$">|; 

$key = q/L_varepsilon^{(3)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img238.png"
 ALT="$L_\varepsilon^{(3)}$">|; 

$key = q/L_varepsilon^{(7)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img237.png"
 ALT="$L_\varepsilon^{(7)}$">|; 

$key = q/{displaymath}kappa=frac{F_varepsilon^{obs}left(frac{Deltavarepsilon}{varepsilon}right)}{F_n^{mod}}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="111" HEIGHT="58" BORDER="0"
 SRC="|."$dir".q|img115.png"
 ALT="\begin{displaymath}\kappa=\frac{F_\varepsilon^{obs} \left(\frac{\Delta\varepsilon}{\varepsilon}\right)}{F_n^{mod}}\end{displaymath}">|; 

$key = q/#;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img264.png"
 ALT="$\char93 $">|; 

$key = q/e-e;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="$e-e$">|; 

$key = q/M_i^0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img86.png"
 ALT="$M_i^0$">|; 

$key = q/L_varepsilon^{source};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="56" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img118.png"
 ALT="$L_\varepsilon^{source}$">|; 

$key = q/L_i^{(2)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img215.png"
 ALT="$L_i^{(2)}$">|; 

$key = q/{displaymath}rate=r1slashT^{r2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="106" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img258.png"
 ALT="\begin{displaymath}rate=r1/T^{r2}\end{displaymath}">|; 

$key = q/_{th};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img326.png"
 ALT="$_{th}$">|; 

$key = q/slashxi;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img99.png"
 ALT="$/xi$">|; 

$key = q/N;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="$N$">|; 

$key = q/{displaymath}frac{{{rm{d}L_{varepsilon}^{(1)}}{{{rm{d}R}=-kappa_{cont}(varepsiloepsilon}^{(1)}+4piR^2j_{varepsilon}(R)eqno{(12)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="410" HEIGHT="52" BORDER="0"
 SRC="|."$dir".q|img199.png"
 ALT="\begin{displaymath}\frac{{\rm d}L_{\varepsilon}^{(1)}}{{\rm d}R}=-\kappa_{cont}(...
...{\varepsilon}^{(1)}
+ 4 \pi R^2 j_{\varepsilon}(R) \eqno{(12)} \end{displaymath}">|; 

$key = q/chi^2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img255.png"
 ALT="$\chi^2$">|; 

$key = q/{displaymath}ch=1.slashchi{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="85" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img277.png"
 ALT="\begin{displaymath}ch = 1./chi\end{displaymath}">|; 

$key = q/Xi;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$\Xi $">|; 

$key = q/{figure}{epsfxsize{=5.6in<comment_mark>12{epsfysize{=7.0in<comment_mark>13{epsffile{warmabsfig1.epsi}{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="643" HEIGHT="803" BORDER="0"
 SRC="|."$dir".q|img93.png"
 ALT="\begin{figure}
\epsfxsize =5.6in % narrow the plot\epsfysize =7.0in % shorten the plot
\epsffile{warmabsfig1.epsi}\end{figure}">|; 

$key = q/f_varepsilonsimvarepsilon^3slash[{{rm{exp}(varepsilonslashkT)-1];MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="186" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img147.png"
 ALT="$f_\varepsilon\sim\varepsilon^3/[{\rm exp}(\varepsilon/kT) -1]$">|; 

$key = q/{displaymath}fchi=0.3*ch*(a+b*(1.+ch)+(c-(a+b*(2.+ch))*ch)*alpha+d*beta*ch){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="552" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img278.png"
 ALT="\begin{displaymath}fchi = 0.3*ch*(a+b*(1.+ch)+(c-(a+b*(2.+ch))*ch)*alpha+d*beta*ch)\end{displaymath}">|; 

$key = q/^{17};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img292.png"
 ALT="$^{17}$">|; 

$key = q/{displaymath}rate=2*(2.105times10^{-22})*vth*y*phi{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="291" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img280.png"
 ALT="\begin{displaymath}rate=2*(2.105 \times 10^{-22})*vth*y*\phi\end{displaymath}">|; 

$key = q/{n_i}^*;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img174.png"
 ALT="${n_i}^*$">|; 

$key = q/{displaymath}L_varepsilon=int_{R_{inner}}^{R_{outer}}{4piR^2j_varepsilon(R)e^{-tau_{cont.}(R,varepsilon)}dR}eqno{(11)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="420" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img193.png"
 ALT="\begin{displaymath}L_\varepsilon=\int_{R_{inner}}^{R_{outer}}{4\pi R^2 j_\varepsilon(R)
e^{-\tau_{cont.}(R,\varepsilon)}dR} \eqno{(11)} \end{displaymath}">|; 

$key = q/^{28};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$^{28}$">|; 

$key = q/&;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img250.png"
 ALT="$\&amp;$">|; 

$key = q/2.3n;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="37" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="$2.3 n$">|; 

$key = q/{displaymath}L_varepsilon^{(5)}=L_{varepsilon}^{(inc)}e^{-tau^{(tot)}(varepsilon)}eqno{(24)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="357" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img231.png"
 ALT="\begin{displaymath}L_\varepsilon^{(5)}=L_{\varepsilon}^{(inc)} e^{-\tau^{(tot)}(\varepsilon)} \eqno{(24)} \end{displaymath}">|; 

$key = q/f;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img116.png"
 ALT="$f$">|; 

$key = q/{displaymath}L_{line,varepsilon}^{(in)}=Sigma_{inimidvarepsilon_i-varepsilonmidlrepsilon-varepsilon_i)}{Deltavarepsilon}eqno(20){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="406" HEIGHT="52" BORDER="0"
 SRC="|."$dir".q|img224.png"
 ALT="\begin{displaymath}L_{line, \varepsilon}^{(in)}=\Sigma_{i \ni \mid\varepsilon_i ...
... \phi(\varepsilon-\varepsilon_i)}{\Delta \varepsilon} \eqno(20)\end{displaymath}">|; 

$key = q/U_H=F_Hslashn;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="96" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img151.png"
 ALT="$U_H=F_H/n$">|; 

$key = q/y;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img77.png"
 ALT="$y$">|; 

$key = q/xi)leq1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img293.png"
 ALT="$\xi) \leq 1$">|; 

$key = q/^{13};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img58.png"
 ALT="$^{13}$">|; 

$key = q/int_0^inftyf_varepsilondvarepsilon=1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="97" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img145.png"
 ALT="$\int_0^\infty f_\varepsilon d\varepsilon=1$">|; 

$key = q/{displaymath}A(varepsilon)=varepsilon^3slash(exp(varepsilonslashkT)-1){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="203" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="\begin{displaymath}
A(\varepsilon) = \varepsilon^3 / (\exp(\varepsilon/kT)-1)
\end{displaymath}">|; 

$key = q/f_varepsilonsimvarepsilon^{alpha};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img148.png"
 ALT="$f_\varepsilon\sim\varepsilon^{\alpha}$">|; 

$key = q/{displaymath}rate=10^{r1+r2*(log_{10}(T)+4.-r3)^2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="227" HEIGHT="40" BORDER="0"
 SRC="|."$dir".q|img275.png"
 ALT="\begin{displaymath}rate=10^{r1+r2*(log_{10}(T)+4.-r3)^2}\end{displaymath}">|; 

$key = q/varepsilon^{-1};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="$\varepsilon^{-1}$">|; 

$key = q/tau_i^{(out)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img243.png"
 ALT="$\tau_i^{(out)}$">|; 

$key = q/varepsilonL_varepsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="$\varepsilon L_\varepsilon$">|; 

$key = q/M_i(x_j);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="57" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img72.png"
 ALT="$M_i(x_j)$">|; 

$key = q/{displaymath}n_eGamma_e=1.42times10^{-27}T^{1slash2}z^2n_en_z{{rm{~ergs~cm^{-3}s^{-1}},eqno{(2)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img170.png"
 ALT="\begin{displaymath}n_e\Gamma_e=1.42\times 10^{-27} T^{1/2} z^2 n_e n_z
{\rm&nbsp;ergs&nbsp;cm^{-3} s^{-1}}, \eqno{(2)}\end{displaymath}">|; 

$key = q/g_{ff};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img189.png"
 ALT="$g_{ff}$">|; 

$key = q/{displaymath}L_varepsilon^{(4)}=int_{R_{inner}}^{R_{outer}}{4piR^2j_varepsilon(Rarepsilon)}P_{esc,cont.}^{(out)}(R)dR}eqno{(16)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img208.png"
 ALT="\begin{displaymath}L_\varepsilon^{(4)}=\int_{R_{inner}}^{R_{outer}}{4\pi R^2 j_\...
...{(out)}(\varepsilon)}
P_{esc, cont.}^{(out)}(R)dR} \eqno{(16)} \end{displaymath}">|; 

$key = q/^{44};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img126.png"
 ALT="$^{44}$">|; 

$key = q/{displaymath}tau_{i}^{(in)}(R)=int_{R_{inner}}^Rkappa_i{{rm{dR}eqno{(18)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="364" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img221.png"
 ALT="\begin{displaymath}\tau_{i}^{(in)}(R)=\int_{R_{inner}}^R \kappa_i {\rm dR} \eqno{(18)}\end{displaymath}">|; 

$key = q/1leqtau_0leq10^6;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img181.png"
 ALT="$1\leq\tau_0\leq 10^6$">|; 

$key = q/L_varepsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="$L_\varepsilon$">|; 

$key = q/{displaymath}M_i(y)=e^{-tau_i(y)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="115" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img81.png"
 ALT="\begin{displaymath}M_i(y)=e^{-\tau_i(y)}\end{displaymath}">|; 

$key = q/tau_0geq10^6;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="68" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img182.png"
 ALT="$\tau_0\geq 10^6$">|; 

$key = q/{displaymath}tau_{cont}^{(tot)}(varepsilon)=int_{R_{inner}}^{R_{outer}}kappa_{cont}(varepsilon)dReqno{(14)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="387" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img206.png"
 ALT="\begin{displaymath}\tau_{cont}^{(tot)}(\varepsilon)=\int_{R_{inner}}^{R_{outer}} \kappa_{cont}(\varepsilon) dR \eqno{(14)}\end{displaymath}">|; 

$key = q/j_varepsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img195.png"
 ALT="$j_\varepsilon$">|; 

$key = q/bullet;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img323.png"
 ALT="$\bullet$">|; 

$key = q/^{10};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img133.png"
 ALT="$^{10}$">|; 

$key = q/{displaymath}C_m^{obs}=Sigma_n{F_varepsilon^{obs}A_{nm}}left(frac{Deltavarepsilon}{varepsilon}right){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="194" HEIGHT="54" BORDER="0"
 SRC="|."$dir".q|img112.png"
 ALT="\begin{displaymath}C_m^{obs}=\Sigma_n{F_\varepsilon^{obs} A_{nm}}\left(\frac{\Delta\varepsilon}{\varepsilon}\right)\end{displaymath}">|; 

$key = q/kappa;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img108.png"
 ALT="$\kappa$">|; 

$key = q/^2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="$^2$">|; 

$key = q/Xi=Lslash(4piR^2cnkT);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="154" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img155.png"
 ALT="$\Xi=L/(4\pi R^2 cnkT)$">|; 

$key = q/{displaymath}P_{esc.,cont.}={{1}over{1000tau_{cont.}+1}}eqno{(5)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="375" HEIGHT="54" BORDER="0"
 SRC="|."$dir".q|img178.png"
 ALT="\begin{displaymath}P_{esc., cont.}={{1}\over{1000 \tau_{cont.}+1}} \eqno{(5)} \end{displaymath}">|; 

$key = q/Delta;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img272.png"
 ALT="$\Delta$">|; 

$key = q/cm^{-3};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="$cm^{-3}$">|; 

$key = q/E_i^0=-{{rm{ln}(M_i^0);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="117" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img90.png"
 ALT="$E_i^0=-{\rm ln}(M_i^0)$">|; 

$key = q/{displaymath}tau_{i}^{(out)}(R)=int_R^{R_{outer}}kappa_i{{rm{dR}eqno{(19)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="370" HEIGHT="54" BORDER="0"
 SRC="|."$dir".q|img222.png"
 ALT="\begin{displaymath}\tau_{i}^{(out)}(R)=\int_R^{R_{outer}} \kappa_i {\rm dR} \eqno{(19)}\end{displaymath}">|; 

$key = q/{displaymath}M_i=M_i^0+Sigma_jx_jM_i^j{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="154" HEIGHT="45" BORDER="0"
 SRC="|."$dir".q|img85.png"
 ALT="\begin{displaymath}
M_i=M_i^0+\Sigma_j x_j M_i^j
\end{displaymath}">|; 

$key = q/P;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img156.png"
 ALT="$P$">|; 

$key = q/tau_{cont.};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img179.png"
 ALT="$\tau_{cont.}$">|; 

$key = q/1.5times10^{24};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="80" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="$1.5 \times 10^{24}$">|; 

$key = q/L_{0varepsilon}=Lf_varepsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img142.png"
 ALT="$L_{0\varepsilon}=Lf_\varepsilon$">|; 

$key = q/i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="10" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img65.png"
 ALT="$i$">|; 

$key = q/n_{infty};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img172.png"
 ALT="$n_{\infty}$">|; 

$key = q/L_varepsilonsimvarepsilon^{alpha};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="64" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="$L_\varepsilon\sim\varepsilon^{\alpha}$">|; 

$key = q/n_{upper};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img176.png"
 ALT="$n_{upper}$">|; 

$key = q/10^4K;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$10^4 K$">|; 

$key = q/tau_0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img180.png"
 ALT="$\tau_0$">|; 

$key = q/{figure}{epsfxsize{=5.6in<comment_mark>24{epsfysize{=7.0in<comment_mark>25{epsffile{warmabsfig7.epsi}{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="643" HEIGHT="803" BORDER="0"
 SRC="|."$dir".q|img101.png"
 ALT="\begin{figure}
\epsfxsize =5.6in % narrow the plot\epsfysize =7.0in % shorten the plot
\epsffile{warmabsfig7.epsi}\end{figure}">|; 

$key = q/{displaymath}F_n^{mod}=frac{L_varepsilon^{xstar}}{L_{tot}^{xstar}}left(frac{Deltavarepsilon}{varepsilon}right)8.356times10^{-7}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="264" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img105.png"
 ALT="\begin{displaymath}F_n^{mod}=\frac{L_\varepsilon^{xstar}}{L_{tot}^{xstar}} \left(\frac{\Delta\varepsilon}{\varepsilon}\right) 8.356 \times 10^{-7}\end{displaymath}">|; 

$key = q/(0.0ldots100.0);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="106" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="$(0.0 \ldots 100.0)$">|; 

$key = q/tau_i^{(in)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img242.png"
 ALT="$\tau_i^{(in)}$">|; 

$key = q/^{-2};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$^{-2}$">|; 

$key = q/prodlimits_{{rm{i=1}^{{{rm{N}_{{rm{I}}n_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="62" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img68.png"
 ALT="$\prod\limits_{\rm i=1}^{{\rm N}_{\rm
I}} n_i$">|; 

$key = q/Gamma=F_nu(nu_L)slash(2hcn);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="149" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img153.png"
 ALT="$\Gamma=F_\nu(\nu_L)/(2hcn)$">|; 

$key = q/phi(varepsilon-varepsilon_i);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img229.png"
 ALT="$\phi(\varepsilon-\varepsilon_i)$">|; 

$key = q/{displaymath}rate=r1*e^{-r2slashkT}+r3*(T^{-r4-r5*ln(T)}){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="312" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img266.png"
 ALT="\begin{displaymath}rate=r1*e^{-r2/kT} + r3*(T^{-r4-r5*ln(T)})\end{displaymath}">|; 

$key = q/M_i(0);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img83.png"
 ALT="$M_i(0)$">|; 

$key = q/f_varepsilonsim{{rm{exp}(-varepsilonslashkT);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="136" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img146.png"
 ALT="$f_\varepsilon\sim {\rm exp}(-\varepsilon/kT)$">|; 

$key = q/L_varepsilon^{(4)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img239.png"
 ALT="$L_\varepsilon^{(4)}$">|; 

$key = q/10^4;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img257.png"
 ALT="$10^4$">|; 

$key = q/{displaymath}crosssection=10^{Sigma_{n=1}^{n=12}C_n(ln(varepsilonslashvarepsilon_0))^{n-1}-18}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="298" HEIGHT="40" BORDER="0"
 SRC="|."$dir".q|img270.png"
 ALT="\begin{displaymath}cross section=10^{\Sigma_{n=1}^{n=12}C_n (ln(\varepsilon/\varepsilon_0))^{n-1}-18}\end{displaymath}">|; 

$key = q/^{total}_{ij};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="33" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img284.png"
 ALT="$^{total}_{ij}$">|; 

$key = q/10^{16};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="$10^{16}$">|; 

$key = q/^{20};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img128.png"
 ALT="$^{20}$">|; 

$key = q/leq3000K;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$\leq 3000 K$">|; 

$key = q/{displaymath}Hleft({{varepsilon}over{varepsilon_0}}right)=12left({{varepsilon}ov{{varepsilon}over{varepsilon_0}}right)eqno{(10)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="391" HEIGHT="54" BORDER="0"
 SRC="|."$dir".q|img190.png"
 ALT="\begin{displaymath}H\left({{\varepsilon}\over{\varepsilon_0}}\right)=
12\left({{...
...\left(1-{{\varepsilon}\over{\varepsilon_0}}\right) \eqno{(10)} \end{displaymath}">|; 

$key = q/L_varepsilon^{(1')};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="47" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img244.png"
 ALT="$L_\varepsilon^{(1')}$">|; 

$key = q/{figure}{epsfxsize{=5.6in<comment_mark>16{epsfysize{=7.0in<comment_mark>17{epsffile{warmabsfig3.epsi}{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="643" HEIGHT="803" BORDER="0"
 SRC="|."$dir".q|img96.png"
 ALT="\begin{figure}
\epsfxsize =5.6in % narrow the plot\epsfysize =7.0in % shorten the plot
\epsffile{warmabsfig3.epsi}\end{figure}">|; 

$key = q/{displaymath}P_{esc.,line}(tau_{line})={{1}over{tau_{line}sqrt{pi}(1.2+b)}}(tau_{line}geq1)eqno{(6)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="442" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img183.png"
 ALT="\begin{displaymath}P_{esc., line}(\tau_{line})={{1}\over{\tau_{line}\sqrt{\pi}(1.2+b)}} (\tau_{line}\geq 1) \eqno{(6)} \end{displaymath}">|; 

$key = q/H^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img268.png"
 ALT="$H^+$">|; 

$key = q/{displaymath}rate=r1*e^{r2slashkT}slashT^{1slash2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="176" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img260.png"
 ALT="\begin{displaymath}rate=r1*e^{r2/kT}/T^{1/2}\end{displaymath}">|; 

$key = q/tau_w=10^5;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img187.png"
 ALT="$\tau_w=10^5$">|; 

$key = q/{{rm{N}_{{rm{I};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img64.png"
 ALT="${\rm N}_{\rm I}$">|; 

$key = q/{figure}{epsfxsize{=5.6in<comment_mark>14{epsfysize{=7.0in<comment_mark>15{epsffile{warmabsfig2.epsi}{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="643" HEIGHT="803" BORDER="0"
 SRC="|."$dir".q|img94.png"
 ALT="\begin{figure}
\epsfxsize =5.6in % narrow the plot\epsfysize =7.0in % shorten the plot
\epsffile{warmabsfig2.epsi}\end{figure}">|; 

$key = q/AA;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="$\AA$">|; 

$key = q/leq{{rm{log}(xi)leq;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img327.png"
 ALT="$\leq {\rm log}(\xi) \leq$">|; 

$key = q/^{-15};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img56.png"
 ALT="$^{-15}$">|; 

$key = q/j_{varepsilon};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img202.png"
 ALT="$j_{\varepsilon}$">|; 

$key = q/Xi=Lslash(4picR^2P);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="135" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="$\Xi = L/(4\pi c R^2 P)$">|; 

$key = q/nleq;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="33" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img287.png"
 ALT="$n \leq$">|; 

$key = q/{figure}{epsfxsize{=5.6in<comment_mark>35{epsfysize{=7.0in<comment_mark>36{epsffile{xstarflow.eps}{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="639" HEIGHT="805" BORDER="0"
 SRC="|."$dir".q|img253.png"
 ALT="\begin{figure}
\epsfxsize =5.6in % narrow the plot\epsfysize =7.0in % shorten the plot
\epsffile{xstarflow.eps}\end{figure}">|; 

$key = q/alpha;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="$\alpha$">|; 

$key = q/L_varepsilon^{source}=L_varepsilon^{xstar}L_{tot}^{source}slashL_{tot}^{xstar};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="230" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img124.png"
 ALT="$L_\varepsilon^{source}=L_\varepsilon^{xstar} L_{tot}^{source}/L_{tot}^{xstar}$">|; 

$key = q/Gamma=2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="47" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img141.png"
 ALT="$\Gamma=2$">|; 

$key = q/{displaymath}Deltavarepsilonslashvarepsilon=(40{{rm{keV}slash0.1{{rm{eV})^{1slash(0.49{{rm{ncn2})}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="249" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="\begin{displaymath}\Delta\varepsilon/\varepsilon=(40 {\rm keV}/0.1 {\rm eV})^{1/(0.49 {\rm ncn2})}\end{displaymath}">|; 

$key = q/f_varepsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img144.png"
 ALT="$f_\varepsilon$">|; 

$key = q/{displaymath}L_varepsilon^{(7)}=L_varepsilon^{(4)}+L_{line,varepsilon}^{(out)}eqno{(26)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="351" HEIGHT="48" BORDER="0"
 SRC="|."$dir".q|img233.png"
 ALT="\begin{displaymath}L_\varepsilon^{(7)}=L_\varepsilon^{(4)}+L_{line, \varepsilon}^{(out)} \eqno{(26)} \end{displaymath}">|; 

$key = q/xi=LslashnR^2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="88" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img149.png"
 ALT="$\xi=L/nR^2$">|; 

$key = q/tau_i(y);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img82.png"
 ALT="$\tau_i(y)$">|; 

$key = q/^5;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img294.png"
 ALT="$^5$">|; 

$key = q/tau_ele0.3;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="65" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img160.png"
 ALT="$\tau_e\le0.3$">|; 

$key = q/L_{tot}^{xstar};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img103.png"
 ALT="$L_{tot}^{xstar}$">|; 

$key = q/{{rm{N}_{{rm{A};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img69.png"
 ALT="${\rm N}_{\rm A}$">|; 

$key = q/left(frac{Deltavarepsilon}{varepsilon}right);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img106.png"
 ALT="$\left(\frac{\Delta\varepsilon}{\varepsilon}\right)$">|; 

$key = q/_{effective};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="62" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img263.png"
 ALT="$_{effective}$">|; 

$key = q/^{5.13};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img63.png"
 ALT="$^{5.13}$">|; 

$key = q/10^7;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="$10^7$">|; 

$key = q/{displaymath}({{rm{N}_{{rm{A}+1)prodlimits_{{rm{i=1}^{{{rm{N}_{{rm{I}}n_i{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="107" HEIGHT="61" BORDER="0"
 SRC="|."$dir".q|img70.png"
 ALT="\begin{displaymath}
({\rm N}_{\rm A}+1) \prod\limits_{\rm i=1}^{{\rm N}_{\rm I}} n_i
\end{displaymath}">|; 

$key = q/^{19};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img127.png"
 ALT="$^{19}$">|; 

$key = q/_{Threshold};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img285.png"
 ALT="$_{Threshold}$">|; 

$key = q/^{37};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img129.png"
 ALT="$^{37}$">|; 

$key = q/{displaymath}alpha_i=({{n_i}over{n_{i+1}n_e}})^*int_{varepsilon_{th}}^{infty}{{de^{(varepsilon_{th}-varepsilon)slashkT}eqno{(3)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="430" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img173.png"
 ALT="\begin{displaymath}\alpha_i=({{n_i}\over{n_{i+1} n_e}})^*
\int_{\varepsilon_{th...
... \sigma_{pi}
e^{(\varepsilon_{th}-\varepsilon)/kT} \eqno{(3)} \end{displaymath}">|; 

$key = q/n=n_0(RslashR_0)^{{rm{radexp};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="153" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="$n=n_0(R/R_0)^{\rm radexp}$">|; 

$key = q/tau_e;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img159.png"
 ALT="$\tau_e$">|; 

$key = q/1.0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="$1.0$">|; 

$key = q/R_0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="$R_0$">|; 

$key = q/tau_{i}^{(out)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img220.png"
 ALT="$\tau_{i}^{(out)}$">|; 

$key = q/^{21.3};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img61.png"
 ALT="$^{21.3}$">|; 

$key = q/n_0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="$n_0$">|; 

$key = q/{figure}{epsfxsize{=5.6in<comment_mark>22{epsfysize{=7.0in<comment_mark>23{epsffile{warmabsfig6.epsi}{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="643" HEIGHT="803" BORDER="0"
 SRC="|."$dir".q|img100.png"
 ALT="\begin{figure}
\epsfxsize =5.6in % narrow the plot\epsfysize =7.0in % shorten the plot
\epsffile{warmabsfig6.epsi}\end{figure}">|; 

$key = q/sigma_T;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img167.png"
 ALT="$\sigma_T$">|; 

$key = q/tau_{i}^{(in)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img219.png"
 ALT="$\tau_{i}^{(in)}$">|; 

$key = q/%%%%;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="62" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img256.png"
 ALT="$\%\%\%\%$">|; 

$key = q/varepsilonleq;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img271.png"
 ALT="$\varepsilon \leq$">|; 

$key = q/L_{varepsilon}^{(1)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img198.png"
 ALT="$L_{\varepsilon}^{(1)}$">|; 

$key = q/10^{18};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="$10^{18}$">|; 

$key = q/L_varepsilon^{(inc)};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img234.png"
 ALT="$L_\varepsilon^{(inc)}$">|; 

$key = q/{displaymath}frac{dL_i^{(2)}}{dR}=-kappa_{cont}(varepsilon)L_i^{(2)}+4piR^2j_i(R)P_{esc,line}^{(out)}eqno{(17)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="437" HEIGHT="52" BORDER="0"
 SRC="|."$dir".q|img213.png"
 ALT="\begin{displaymath}\frac{d L_i^{(2)}}{dR}=-\kappa_{cont}(\varepsilon) L_i^{(2)}
+ 4 \pi R^2 j_i(R) P_{esc,line}^{(out)} \eqno{(17)} \end{displaymath}">|; 

$key = q/L_varepsilon^{source}=L_varepsilon^{xstar};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="125" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img121.png"
 ALT="$L_\varepsilon^{source}=L_\varepsilon^{xstar}$">|; 

$key = q/sigma_{pi};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img177.png"
 ALT="$\sigma_{pi}$">|; 

$key = q/F_nu(nu_L);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="56" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img154.png"
 ALT="$F_\nu(\nu_L)$">|; 

$key = q/10^9K;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="$10^9 K$">|; 

$key = q/{displaymath}C_m^{mod}=kappaSigma_n{F_n^{mod}A_{nm}}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="168" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img109.png"
 ALT="\begin{displaymath}C_m^{mod}=\kappa \Sigma_n{F_n^{mod} A_{nm}}\end{displaymath}">|; 

$key = q/{displaymath}tau^{(tot)}(varepsilon)=int_{R_{inner}}^{R_{outer}}(kappa_{cont}(valon)+kappa_{line}(varepsilon)){{rm{dR}eqno{(23)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="430" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img230.png"
 ALT="\begin{displaymath}\tau^{(tot)}(\varepsilon)=\int_{R_{inner}}^{R_{outer}}
(\kap...
...}(\varepsilon)+\kappa_{line}(\varepsilon)) {\rm dR} \eqno{(23)}\end{displaymath}">|; 

$key = q/{displaymath}j_varepsilon=n_{upper}n_e({{n_i}over{n_{i+1}n_e}})^*{{varepsilon^3}e^{(varepsilon_{th}-varepsilon)slashkT}eqno{(4)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="433" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img175.png"
 ALT="\begin{displaymath}j_\varepsilon=n_{upper} n_e ({{n_i}\over{n_{i+1} n_e}})^*
{{...
... \sigma_{pi}
e^{(\varepsilon_{th}-\varepsilon)/kT} \eqno{(4)} \end{displaymath}">|; 

$key = q/geq10^9K;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="64" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$\geq 10^9 K$">|; 

$key = q/E_i^j;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img91.png"
 ALT="$E_i^j$">|; 

$key = q/Upsilon;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img281.png"
 ALT="$\Upsilon$">|; 

$key = q/epsilon=10^{-8};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="70" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img163.png"
 ALT="$\epsilon=10^{-8}$">|; 

$key = q/E^{alpha};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$E^{\alpha}$">|; 

$key = q/R;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img150.png"
 ALT="$R$">|; 

$key = q/C=2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img139.png"
 ALT="$C=2$">|; 

$key = q/int{(L_{varepsilon}^{(inc)}-L_{varepsilon}^{(1)})}dvarepsilon-Sigma_i(L_i^{(1)}+L_i^{(2)});MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="276" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img246.png"
 ALT="$\int{(L_{\varepsilon}^{(inc)} - L_{\varepsilon}^{(1)})}d\varepsilon - \Sigma_i(L_i^{(1)}+L_i^{(2)})$">|; 

$key = q/DeltaRslashR;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="$\Delta R/R$">|; 

$key = q/L_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img197.png"
 ALT="$L_i$">|; 

$key = q/(Ln)^{1slash2};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img157.png"
 ALT="$(Ln)^{1/2}$">|; 

$key = q/P_{esc,line}^{(out)}=(1-C)P_{esc.,line}(tau_{i}^{(out)})+CP_{esc.,line}(tau_{i}^{(out)}+tau_{i}^{(in)})slash2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="479" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img218.png"
 ALT="$P_{esc, line}^{(out)}=(1-C) P_{esc., line}(\tau_{i}^{(out)})
+ C P_{esc., line}(\tau_{i}^{(out)}+\tau_{i}^{(in)})/2$">|; 

$key = q/^3;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img252.png"
 ALT="$^3$">|; 

$key = q/{displaymath}L_varepsilon^{(6)}=L_varepsilon^{(3)}+L_{line,varepsilon}^{(in)}eqno{(25)}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="351" HEIGHT="48" BORDER="0"
 SRC="|."$dir".q|img232.png"
 ALT="\begin{displaymath}L_\varepsilon^{(6)}=L_\varepsilon^{(3)}+L_{line, \varepsilon}^{(in)} \eqno{(25)} \end{displaymath}">|; 

$key = q/^{-5};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$^{-5}$">|; 

$key = q/{displaymath}(8+1)(5)(4)=180calls{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="180" HEIGHT="44" BORDER="0"
 SRC="|."$dir".q|img71.png"
 ALT="\begin{displaymath}
(8+1)(5)(4) = 180 calls
\end{displaymath}">|; 

1;

