# LaTeX2HTML 2002-2-1 (1.70)
# Associate labels original text with physical files.


$key = q/sec:physics/;
$external_labels{$key} = "$URL/" . q|node110.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_George1999/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:14a/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:5b/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Hollenbach1978/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_topbase/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Karzas1966/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xstar2xspec/;
$external_labels{$key} = "$URL/" . q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:xstarflow/;
$external_labels{$key} = "$URL/" . q|node144.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:4b/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bautista1999/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Field1971/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Shull1979/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:6_/;
$external_labels{$key} = "$URL/" . q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:16a/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:xstar2xspec/;
$external_labels{$key} = "$URL/" . q|node146.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Harrington1989/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xstarinput/;
$external_labels{$key} = "$URL/" . q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Lotz1967/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lexington/;
$external_labels{$key} = "$URL/" . q|node149.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bautista1997/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kallman1980/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Tucker1971/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Gould1970/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:internals/;
$external_labels{$key} = "$URL/" . q|node131.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bautista2000/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:3_oxygen_1__other_metals_0__etable/;
$external_labels{$key} = "$URL/" . q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Mendosa1982/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Osterbrock1974/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ross1979/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_chianti/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:spectra/;
$external_labels{$key} = "$URL/" . q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_opacityp/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_London1979/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:introduction/;
$external_labels{$key} = "$URL/" . q|node2.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pitfalls/;
$external_labels{$key} = "$URL/" . q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:9b/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:15b/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Krolik1981/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:7a/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:4a/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:3a/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:9a/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Press/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:14b/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Butler1980/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:8a/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Nahar1999/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sampsonzhang/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Comparison_of_grid19b__19c__and_warmabs/;
$external_labels{$key} = "$URL/" . q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Aldrovandi1973/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:2/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Verner1995/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:3b/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ross1978/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Dalgarno1981/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Grevesse1996/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Hatchett1976/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Illarionov1979/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:5a/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Arnaud1985/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kallman1982/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:8b/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:12/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Weisheit1974/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Barfield1972/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:overview/;
$external_labels{$key} = "$URL/" . q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kwan1981/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:6a/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:1a/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:13b/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:1b/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:atomicdatabase/;
$external_labels{$key} = "$URL/" . q|node163.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:troubleshooting/;
$external_labels{$key} = "$URL/" . q|node159.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:warmabs/;
$external_labels{$key} = "$URL/" . q|node99.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:7b/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:walkthrough/;
$external_labels{$key} = "$URL/" . q|node7.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Davidson1979/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:15a/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kaastra1989/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:revision/;
$external_labels{$key} = "$URL/" . q|node188.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bautista1998/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kallman1983/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Nahar2000/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:11a/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:16b/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:6b/;
$external_labels{$key} = "$URL/" . q|node186.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Arnaud1992/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:installation/;
$external_labels{$key} = "$URL/" . q|node166.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Bambynek1972/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:11b/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:1_cosmic_abundances__mtable/;
$external_labels{$key} = "$URL/" . q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Hummer1968/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Raymond1976/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:_7_/;
$external_labels{$key} = "$URL/" . q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Halpern1980/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ironp/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:4_oxygen_1__other_metals_0__mtable/;
$external_labels{$key} = "$URL/" . q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Tarter1969/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Hummer1971/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:13a/;
$external_labels{$key} = "$URL/" . q|node187.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Dalgarno1978/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:2_cosmic_abundances__etable/;
$external_labels{$key} = "$URL/" . q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:output/;
$external_labels{$key} = "$URL/" . q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_McCray1977/;
$external_labels{$key} = "$URL/" . q|node217.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.70)
# labels from external_latex_labels array.


$key = q/sec:physics/;
$external_latex_labels{$key} = q|9|; 
$noresave{$key} = "$nosave";

$key = q/fig:14a/;
$external_latex_labels{$key} = q|14|; 
$noresave{$key} = "$nosave";

$key = q/fig:5a/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/fig:5b/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/fig:8b/;
$external_latex_labels{$key} = q|8|; 
$noresave{$key} = "$nosave";

$key = q/sec:xstar2xspec/;
$external_latex_labels{$key} = q|7|; 
$noresave{$key} = "$nosave";

$key = q/fig:12/;
$external_latex_labels{$key} = q|12|; 
$noresave{$key} = "$nosave";

$key = q/fig:xstarflow/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/sec:overview/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/fig:4b/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/fig:1a/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/fig:6a/;
$external_latex_labels{$key} = q|6|; 
$noresave{$key} = "$nosave";

$key = q/sec:atomicdatabase/;
$external_latex_labels{$key} = q|13|; 
$noresave{$key} = "$nosave";

$key = q/fig:1b/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/fig:13b/;
$external_latex_labels{$key} = q|13|; 
$noresave{$key} = "$nosave";

$key = q/fig:6_/;
$external_latex_labels{$key} = q|7|; 
$noresave{$key} = "$nosave";

$key = q/fig:xstar2xspec/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/fig:16a/;
$external_latex_labels{$key} = q|16|; 
$noresave{$key} = "$nosave";

$key = q/sec:warmabs/;
$external_latex_labels{$key} = q|8|; 
$noresave{$key} = "$nosave";

$key = q/sec:xstarinput/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/sec:troubleshooting/;
$external_latex_labels{$key} = q|12|; 
$noresave{$key} = "$nosave";

$key = q/fig:7b/;
$external_latex_labels{$key} = q|7|; 
$noresave{$key} = "$nosave";

$key = q/sec:walkthrough/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/sec:lexington/;
$external_latex_labels{$key} = q|11|; 
$noresave{$key} = "$nosave";

$key = q/sec:internals/;
$external_latex_labels{$key} = q|10|; 
$noresave{$key} = "$nosave";

$key = q/fig:3_oxygen_1__other_metals_0__etable/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/fig:15a/;
$external_latex_labels{$key} = q|15|; 
$noresave{$key} = "$nosave";

$key = q/fig:11a/;
$external_latex_labels{$key} = q|11|; 
$noresave{$key} = "$nosave";

$key = q/fig:16b/;
$external_latex_labels{$key} = q|16|; 
$noresave{$key} = "$nosave";

$key = q/fig:6b/;
$external_latex_labels{$key} = q|6|; 
$noresave{$key} = "$nosave";

$key = q/sec:spectra/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/sec:installation/;
$external_latex_labels{$key} = q|14|; 
$noresave{$key} = "$nosave";

$key = q/fig:11b/;
$external_latex_labels{$key} = q|11|; 
$noresave{$key} = "$nosave";

$key = q/fig:1_cosmic_abundances__mtable/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/sec:introduction/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/sec:pitfalls/;
$external_latex_labels{$key} = q|6|; 
$noresave{$key} = "$nosave";

$key = q/fig:9b/;
$external_latex_labels{$key} = q|9|; 
$noresave{$key} = "$nosave";

$key = q/fig:15b/;
$external_latex_labels{$key} = q|15|; 
$noresave{$key} = "$nosave";

$key = q/fig:_7_/;
$external_latex_labels{$key} = q|8|; 
$noresave{$key} = "$nosave";

$key = q/fig:7a/;
$external_latex_labels{$key} = q|7|; 
$noresave{$key} = "$nosave";

$key = q/fig:4a/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/fig:3a/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/fig:9a/;
$external_latex_labels{$key} = q|9|; 
$noresave{$key} = "$nosave";

$key = q/fig:14b/;
$external_latex_labels{$key} = q|14|; 
$noresave{$key} = "$nosave";

$key = q/fig:4_oxygen_1__other_metals_0__mtable/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/fig:8a/;
$external_latex_labels{$key} = q|8|; 
$noresave{$key} = "$nosave";

$key = q/fig:13a/;
$external_latex_labels{$key} = q|13|; 
$noresave{$key} = "$nosave";

$key = q/sec:output/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/fig:2_cosmic_abundances__etable/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/fig:Comparison_of_grid19b__19c__and_warmabs/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/fig:2/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/fig:3b/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

1;

